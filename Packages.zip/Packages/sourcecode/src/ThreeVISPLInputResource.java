import java.io.*;
import java.util.Arrays;
import java.util.LinkedList;

public class ThreeVISPLInputResource {

    private LinkedList<String> tokens;
    private LinkedList<String> Treatedtokens;
    private String[] tok;

    public ThreeVISPLInputResource(String fileName) throws ParseError {

        StringBuilder b = new StringBuilder("");
        try {
            BufferedReader reader = new BufferedReader(new FileReader(fileName));
            String line = null;
            while ((line = reader.readLine()) != null) {
                b.append(removeComments(line));
            }
        } catch (FileNotFoundException e) {

            throw new ParseError("Unable to open ISPL Input File !");

        } catch (IOException e) {

            throw new ParseError("Unable to read from the ISPL Input File !");
        }
        String finalValue = b.toString();
        finalValue = finalValue.replaceAll(":", " : ");
        finalValue = finalValue.replaceAll(";", " ; ");
        finalValue = finalValue.replaceAll(",", " , ");
        finalValue = finalValue.replaceAll("\\{", " { ");
        finalValue = finalValue.replaceAll("}", " } ");
        finalValue = finalValue.replaceAll(" and", " and ");
        finalValue = finalValue.replaceAll("=", " = ");
        finalValue = finalValue.replaceAll("\\(", " ( ");
        finalValue = finalValue.replaceAll("\\)", " ) ");
        finalValue = finalValue.replaceAll(" end", " end ");
        finalValue = finalValue.replaceAll("Evolution", " Evolution ");
        finalValue = finalValue.replaceAll("Agent", " Agent ");
        finalValue = finalValue.replaceAll("Evaluation", " Evaluation ");
        finalValue = finalValue.replaceAll("InitStates", " InitStates ");
        tok = finalValue.split("\\s");
        tokens = new LinkedList<String>(Arrays.asList(tok));
        Treatedtokens = new LinkedList<String>(tokens);
        //removeWhiteSpace();
        if (!tokens.isEmpty()) {

        } else {
            throw new ParseError("Empty ISPL input File");
        }

    }

    public ThreeVISPLInputResource(File f) throws ParseError {

        StringBuilder b = new StringBuilder("");
        try {
            BufferedReader reader = new BufferedReader(new FileReader(f));
            String line = null;
            while ((line = reader.readLine()) != null) {
                if (line.contains("--")){
                    b.append(line.split("--")[0]);
                }else{
                    b.append(line);
                }
            }
        } catch (FileNotFoundException e) {

            throw new ParseError("Unable to open ISPL Input File !");

        } catch (IOException e) {

            throw new ParseError("Unable to read from the ISPL Input File !");
        }
        String finalValue = b.toString();
        finalValue = finalValue.replaceAll(":", " : ");
        finalValue = finalValue.replaceAll(";", " ; ");
        finalValue = finalValue.replaceAll(",", " , ");
        finalValue = finalValue.replaceAll("\\{", " { ");
        finalValue = finalValue.replaceAll("}", " } ");
        finalValue = finalValue.replaceAll(" and", " and ");
        finalValue = finalValue.replaceAll("=", " = ");
        finalValue = finalValue.replaceAll("\\(", " ( ");
        finalValue = finalValue.replaceAll("\\)", " ) ");
        finalValue = finalValue.replaceAll(" end", " end ");
        finalValue = finalValue.replaceAll("Evolution", " Evolution ");
        finalValue = finalValue.replaceAll("Agent", " Agent ");
        finalValue = finalValue.replaceAll("Evaluation", " Evaluation ");
        finalValue = finalValue.replaceAll("InitStates", " InitStates ");
        finalValue = finalValue.replaceAll("Formulae", " Formulae ");
        tok = finalValue.split("\\s");
        tokens = new LinkedList<String>(Arrays.asList(tok));
        Treatedtokens = new LinkedList<String>(tokens);
        //removeWhiteSpace();
        if (!tokens.isEmpty()) {

        } else {
            throw new ParseError("Empty ISPL input File");
        }

    }

    public String removeComments(String line) {
        StringBuilder st = new StringBuilder();
        for (int i = 0; i < line.length(); i++) {
            if (line.charAt(i) == '-') {
                if (i < line.length() - 1 && line.charAt(i + 1) == '-') {
                    break;
                } else {
                    st.append(line.charAt(i));
                }
            } else {
                st.append(line.charAt(i));
            }
        }
        return st.toString();
    }

    public String next() {
        skipWhiteSpace();
        return Treatedtokens.pollFirst();
    }

    public void testToOutput() {
        for (String s : Treatedtokens) {
            System.out.println(s);
        }
    }

    public void skipWhiteSpace() {
        String t = Treatedtokens.peekFirst();
        while (t != null && t.trim().equals("")) {
            Treatedtokens.removeFirst();
            t = Treatedtokens.peekFirst();
        }
    }

    public void removeWhiteSpace() {
        Treatedtokens = new LinkedList<String>();
        for (String s : tokens) {
            if (!s.equals("")) {
                Treatedtokens.add(s);
            }
        }
    }

    public LinkedList<String> getTokens() {
        return Treatedtokens;
    }


}
