

 
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import javax.swing.text.JTextComponent;

import javax.swing.*;
import java.awt.*;

public class TrueCTLModelTraslator<pubilc> {	          
    static <D> File transfyFile2(File fFile, String oldString, String newString)
    {       
		File fileToBeModified =   fFile;
                
        String oldContent = "";
         
        BufferedReader reader = null;
         
        //FileWriter writer = null;
         
        try
        {
            reader = new BufferedReader(new FileReader(fileToBeModified));
             
          //Reading all the lines of input text file into oldContent
            
            String line = reader.readLine();
             
            while (line != null) 
            {
                oldContent = oldContent + line + System.lineSeparator();
                 
                line = reader.readLine();
            }
             
            //Replacing oldString with newString in the oldContent
             
            String newContent = oldContent.replaceAll(oldString, newString); 
         //   System.out.println(newContent);
            
          new TextAreaCTLPos(newContent);
            
           //  new TextAreaCTLNeg.initComponents(newContent);
           
           
                 
            System.out.println("done");
            
           
                            	                          
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                //Closing the resources
                 
                reader.close();
                 
               // writer.close();
            } 
            catch (IOException e) 
            {
                e.printStackTrace();
            }
        }
		return fileToBeModified;
    }

	public static void main(String[] args)  
    {
		 
             
    }
	
} 
	
	

