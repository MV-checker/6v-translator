
//package org.kodejava.swing;

import javax.swing.*;
import javax.swing.text.JTextComponent;

import java.awt.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;

public class TextAreaGetContent1 extends JPanel {
    public TextAreaGetContent1() {
        String name = null;
		initializeUI(name);
    }
		

    public static void showFrame() {
        JPanel panel = new TextAreaGetContent1();
        panel.setOpaque(true);

        JFrame frame = new JFrame("JTextArea Demo");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setContentPane(panel);
        frame.pack();
        frame.setVisible(true);
    }
   
    

    public static void main(String[] args) {
        SwingUtilities.invokeLater(TextAreaGetContent1::showFrame);
    }
    public   void initializeUI(String newFile) {
        this.setLayout(new BorderLayout());
        this.setPreferredSize(new Dimension(500, 200));
        final JTextArea textArea = new JTextArea();
        textArea.setText(newFile);
        textArea.setVisible(true);
         	
        	                   
               

        // Set the contents of the JTextArea.
       
        /////////////////////////////////////////////////////////////////////////////
        
    //   textArea.setText(newFile);
       textArea.setLineWrap(true);
       textArea.setWrapStyleWord(true);

        JScrollPane pane = new JScrollPane(textArea);
        pane.setPreferredSize(new Dimension(500, 200));
        pane.setVerticalScrollBarPolicy(
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

     //   JButton button = new JButton("Get Contents");
     //   button.addActionListener(e -> {
            // Get the contents of the JTextArea component.
          //  String contents = textArea.getText();
         //   System.out.println("contents = " + contents);
    //    });
        this.add(pane, BorderLayout.CENTER);
     //   this.add(button, BorderLayout.SOUTH);
    }
    
    }
